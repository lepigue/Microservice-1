import React from 'react';
import { Link } from 'react-router-dom';


function Navigation() {
  return (
    <nav>
        <Link to="/"><img src="https://s3-eu-west-1.amazonaws.com/tpd/logos/5fdd301380728900010a3cd9/0x0.png"></img></Link>
        <Link to="/">Home</Link>
        <Link to="../create-exercise">Add Exercise</Link>
    </nav>
  );
}

export default Navigation;
